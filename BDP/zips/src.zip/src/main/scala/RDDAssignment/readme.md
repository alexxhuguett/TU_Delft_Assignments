# Spark Resilient Distributed Dataset (RDD)

In the Spark RDD assignments you will focus on the basics of Spark RDDs. It is recommended
to read the Spark [documentation](https://spark.apache.org/docs/latest/api/scala/index.html),
as TAs require you to do your own research before asking questions.
