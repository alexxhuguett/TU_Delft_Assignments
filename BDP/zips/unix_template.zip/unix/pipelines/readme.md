In this part, you will implement multiple pipelines. All needed commands are discussed in the lectures and can be found in the slides.

It consists of two parts.
First, you will use some pipelines to do text analysis and manipulation in [mybook.sh](<mybook.sh>). 
Second, you will use some pipelines to help you find information in NASA exoplanet database in [exoplanetPipelines.sh](<exoplanetPipelines.sh>).