In this part, you will create a few scripts to get a feel for automating tasks.

1. create a script that finds 5 most common bigrams in a text file [bigrams.sh](<bigrams.sh>)
2. create a script that will pack the submission file for you in [createSubmission.sh](<createSubmission.sh>)